//
//  SettingsController.h
//  yalu102
//
//  Created by Jake James on 4/22/17.
//  Copyright © 2017 kimjongcracks. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsController : UIViewController {
    IBOutlet UISwitch *esub;
    IBOutlet UISwitch *recydia;
}

@end
