This is not a support forum or generic mailing list.

This form is exclusively for reporting issues caused directly by the inner workings of yalu.

Direct your jailbreaking questions to one of these fine communities:

* https://reddit.com/r/jailbreak
* http://www.jailbreakqa.com/

Issues, which are not related to yalu's code, may be closed without comment. Do NOT post about: Cydia, tweak, respring/bootloop or app issues UNLESS you have evidence that they are caused by an error in the jailbreaking software itself.

(Delete this bit after reading, and replace it by "I read the issue posting guidelines.")
